# CartridgeWriter_V2
Most recent update of the compiled CartridgeWriter written by @slaytonrnd :+1:
* V1: Initial Release by @slaytonrnd
* V2: Added Printer Type uPrint and uPrintSE / Issue #13 fixed - Serial Number is written into Original Quantity
* V3: Corrected display of ManufacturingDate and corrected address of UseDate
* V4: Make UID and Key Fragment copyable, add material database (material.py thanks to @bvanheu)
* V5: Add material for HP DesignJet 3D (P430L_IVR and SR30L - thanks to @silvood) 
